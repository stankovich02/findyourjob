<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Application extends Model
{
   protected $table = 'applications';

    protected $fillable = [
        'job_id',
        'user_id',
        'uploaded_file',
        'cover_letter'
    ];

    public function job() : BelongsTo
    {
        return $this->belongsTo(Job::class);
    }
    public function user() : BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
