<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\RegisterUserRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Str;

class RegisterController extends Controller
{
    public function index()
    {
        return view('pages.client.register');
    }
    public function register(RegisterUserRequest $request)
    {

         $userModel = new User();
         $array = [
                'first_name' => $request->input('firstName'),
                'last_name' => $request->input('lastName'),
                'email' => $request->input('email'),
                'password' => $request->input('password'),
         ];
            $token = $userModel->insert($array);
         Mail::to($request->input('email'))->send(new \App\Mail\EmailVerification($token));
         return redirect()->back()->with('success', 'You have successfully registered! Please check your email to verify your account.');
    }
    public function verify($token)
    {
        $userModel = new User();
        $verified = $userModel->verify($token);
        if ($verified) {
          return redirect()->route('home')->with('verified', true);
        }
        return view('mail.verified')->with('message', 'Your account could not be verified!');

    }
}
