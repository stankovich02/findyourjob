<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\LoginUserRequest;
use App\Models\Company;
use App\Models\User;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    public function index()
    {
        return view('pages.client.login');
    }

    public function login(LoginUserRequest $request)
    {
        try{
            $email = $request->input('email');
            $password = $request->input('password');
            $passwordWithEnv = $password . env('CUSTOM_STRING_FOR_HASH');
            $userModel = new User();
            $companyModel = new Company();
            if($request->input('accountType') == 'worker')
                $user = $userModel::where('email', $email)->first();
            else
                $user = $companyModel::where('email', $email)->first();
            if(!$user || !password_verify($passwordWithEnv, $user->password)){
                return redirect()->back()->with('error', 'Invalid credentials.');
            }
            if($user->is_active == 0 && $request->input('accountType') == 'worker'){
                return redirect()->back()->with('error', 'Account is not verified. Please check your email for verification link');
            }
            $request->session()->put('user', $user);
            $request->session()->put('accountType', $request->input('accountType'));
            return redirect()->route('home');
        }
        catch(\Exception $e){
            return redirect()->back()->with('error', 'An error occurred');
        }
    }

    public function logout(Request $request)
    {
        try {
            $request->session()->forget('user');
            $request->session()->forget('accountType');
            return redirect()->route('home');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'An error occurred');
        }
    }
}
