@extends('layouts.layout')
@section('title')
    FindYourJob | Verification
@endsection
@section('content')
    <h2 class="py- text-center">{{$message}}</h2>
@endsection
