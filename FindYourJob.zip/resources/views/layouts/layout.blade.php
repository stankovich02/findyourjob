<!DOCTYPE html>
<html lang="en">
<head>
    @include("fixed.client.head")
</head>
<body>
    @include("fixed.client.header")

    @yield("content")

    @include("fixed.client.footer")
</body>
</html>

