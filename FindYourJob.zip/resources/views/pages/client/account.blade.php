@extends('layouts.layout')
@section('title')
    FindYourJob | Job
@endsection
@section('content')
<div class="container-xl px-4 mt-5">
    <div class="row">
        <div class="col-xl-4">
            <!-- Profile picture card-->
            <div class="card mb-4 mb-xl-0">
                <div class="card-header">Profile Picture</div>
                <div class="card-body text-center">
                    <!-- Profile picture image-->
                    @if(session('accountType') === 'worker')
                    <img class="img-account-profile rounded-circle mb-2 img-fluid" src="{{asset('assets/img/users/' . session('user')->avatar)}}" alt="">
                    @else
                    <img class="img-account-profile rounded-circle mb-2 img-fluid" src="{{asset('assets/img/companies/' . session('user')->logo)}}" alt="">
                    @endif
                        <!-- Profile picture help block-->
                    <div class="small font-italic text-muted mb-4">JPG or PNG no larger than 5 MB</div>
                    <!-- Profile picture upload button-->
                    <button class="btn btn-primary" type="button">Upload new image</button>
                </div>
            </div>
            @if(session('accountType') === 'worker')
            <div id="profileLinks" class="mt-4">
                <h5 class="font-xl">Profile Links:</h5>
                @if(session('user')->github)
                <div class="d-flex align-items-center mb-2 justify-content-start">
                    <div class="iconDiv d-flex justify-content-center">
                        <i class="fab fa-github fa-2x"></i>
                    </div>
                    <div class="linkDiv d-flex justify-content-between justify-content-between w-100 ms-3 align-items-center">
                        <a href="{{session('user')->github}}">{{session('user')->github}}</a>
                        <button class="btn btn-primary btn-sm ms-2 changeLink">Change</button>
                    </div>
                </div>
                @else
                <div class="d-flex align-items-center mb-2 justify-content-start">
                    <div class="iconDiv d-flex justify-content-center">
                        <i class="fab fa-github fa-2x"></i>
                    </div>
                    <div class="linkDiv d-flex justify-content-between w-100 ms-3 align-items-center">
                        <button class="btn btn-primary addLink" type="button">Add link</button>
                    </div>
                </div>
                @endif
                @if(session('user')->linkedin)
                <div class="d-flex align-items-center justify-content-start">
                    <div class="iconDiv d-flex justify-content-center">
                        <i class="fab fa-linkedin fa-2x"></i>
                    </div>
                    <div class="linkDiv d-flex justify-content-between justify-content-between w-100 ms-3 align-items-center">
                        <a href="{{session('user')->linkedin}}">{{session('user')->linkedin}}</a>
                        <button class="btn btn-primary btn-sm ms-2 changeLink">Change</button>
                    </div>
                </div>
                @else
                    <div class="d-flex align-items-center justify-content-start">
                        <div class="iconDiv d-flex justify-content-center">
                            <i class="fab fa-linkedin fa-2x"></i>
                        </div>
                        <div class="linkDiv d-flex justify-content-between w-100 ms-3 align-items-center">
                            <button class="btn btn-primary addLink" type="button">Add link</button>
                        </div>
                        {{-- <input type="text" id="linkedin" class="form-control border-0"/>--}}
                        {{--<button class="btn btn-primary" type="button">Save</button>--}}
                    </div>
                @endif
            </div>
            @endif
        </div>
        <div class="col-xl-8">
            <!-- Account details card-->
            <div class="card mb-4">
                <div class="card-header">Account Details</div>
                <div class="card-body">
                    <form>
                       @if(session('accountType') === 'company')
                        <div class="mb-3">
                            <label class="small mb-1" for="companyName">Company name</label>
                            <input class="form-control" id="companyName" type="text" disabled value="{{session('user')->name}}">
                        </div>
                        <div class="mb-3">
                            <label class="small mb-1" for="inputBio">Company description</label>
                            <textarea id="inputBio" cols="10" rows="10" disabled class="form-control">{{session('user')->description}}</textarea>
                        </div>
                        <div class="row gx-3 mb-3">
                            <div class="col-md-6">
                                <label class="small mb-1" for="website">Website</label>
                                <input class="form-control" id="website" name="website" type="text" disabled value="{{session('user')->website}}">
                            </div>
                            <div class="col-md-6">
                                <label class="small mb-companyName1" for="phone">Phone</label>
                                <input class="form-control" id="phone" name="phone" type="text" disabled value="{{session('user')->phone}}">
                            </div>
                        </div>
                        @else
                        <div class="row gx-3 mb-3">
                            <div class="col-md-6">
                                <label class="small mb-1" for="firstName">First name</label>
                                <input class="form-control" id="firstName" name="firstName" type="text" disabled value="{{session('user')->first_name}}">
                            </div>
                            <div class="col-md-6">
                                <label class="small mb-companyName1" for="lastName">Last name</label>
                                <input class="form-control" id="lastName" name="lastName" type="text" disabled value="{{session('user')->last_name}}">
                            </div>
                        </div>
                        @endif
                        <div class="row gx-3 mb-3">
                            <div class="col-md-6">
                                <label class="small mb-1" for="email">Email</label>
                                <input class="form-control" id="email" name="email" type="text" disabled value="{{session('user')->email}}">
                            </div>
                        </div>


                        <!-- Save changes button-->
                        <button class="btn btn-primary" type="button">Save changes</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- Za usere "Applied jobs" , za kompanije "Posted jobs"-->
    <h3 class="font-xl pt-5">Applied jobs</h3>
    <div class="job-item p-4 my-4" id="jedan">
        <div class="row g-4">
            <div class="col-sm-12 col-md-8 d-flex align-items-center">
                <img class="flex-shrink-0 img-fluid border rounded" src="assets/img/com-logo-1.jpg"
                     alt="" style="width: 80px; height: 80px;">
                <div class="text-start ps-4">
                    <h5 class="mb-3">Software Engineer</h5>
                    <span class="text-truncate me-3"><i
                            class="fa fa-map-marker-alt text-primary me-2"></i>New York, USA</span>
                    <span class="text-truncate me-3"><i class="far fa-clock text-primary me-2"></i>Full Time</span>
                    <span class="text-truncate me-0"><i
                            class="far fa-money-bill-alt text-primary me-2"></i>$123 - $456</span>
                </div>
            </div>
            <div
                class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center">
                <div class="d-flex mb-3">
                    <a class="btn btn-light btn-square me-3" href="">
                        <i class="far fa-heart text-primary"></i>
                    </a>
                    <!-- za usere  "Apply now, za kompanije "View job"-->
                    <a class="btn btn-primary" href="">Apply Now</a>
                </div>
                <small class="text-truncate"><i class="far fa-calendar-alt text-primary me-2"></i>Date
                    Line: 01 Jan, 2045</small>
            </div>
        </div>
    </div>
    <div class="job-item p-4 my-4" id="dva">
        <div class="row g-4">
            <div class="col-sm-12 col-md-8 d-flex align-items-center">
                <img class="flex-shrink-0 img-fluid border rounded" src="assets/img/com-logo-1.jpg"
                     alt="" style="width: 80px; height: 80px;">
                <div class="text-start ps-4">
                    <h5 class="mb-3">Software Engineer</h5>
                    <span class="text-truncate me-3"><i
                            class="fa fa-map-marker-alt text-primary me-2"></i>New York, USA</span>
                    <span class="text-truncate me-3"><i class="far fa-clock text-primary me-2"></i>Full Time</span>
                    <span class="text-truncate me-0"><i
                            class="far fa-money-bill-alt text-primary me-2"></i>$123 - $456</span>
                </div>
            </div>
            <div
                class="col-sm-12 col-md-4 d-flex flex-column align-items-start align-items-md-end justify-content-center">
                <div class="d-flex mb-3">
                    <a class="btn btn-light btn-square me-3" href=""><i
                            class="far fa-heart text-primary"></i></a>
                    <a class="btn btn-primary" href="">Apply Now</a>
                </div>
                <small class="text-truncate"><i class="far fa-calendar-alt text-primary me-2"></i>Date
                    Line: 01 Jan, 2045</small>
            </div>
        </div>
    </div>
</div>

@endsection
