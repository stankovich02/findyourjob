@extends('layouts.layout')
@section('title')
    FindYourJob | Register
@endsection
@section('content')
    <div class="container py-5" @if ($errors->any() || session("success")) style="opacity: 1!important;display:block!important;" @endif  id="regForm">
        <div class="row d-flex flex-column align-items-center">
        <h2 class="text-center font-xl">Register company</h2>
            <div class="col-lg-5 col-md-7 col-12">
        @if(session('success'))
            <div class="alert-success p-3">
                <p class="text-center m-0 font-medium">{{session('success')}}</p>
            </div>
        @endif
        <form enctype="multipart/form-data" id="registrationForm" name="registrationForm" class="font-small mx-auto" method="POST" action="{{route("companies.store")}}" >
            @csrf
            <div class="my-4">
                <label for="companyName" class="font-small">Company name</label>
                <input type="text" class="form-control font-small" id="companyName" name="companyName" value="{{old("companyName")}}"/>
                {{--<span class="font-small error-message">Jhon</span>--}}
            </div>
            <div class="my-4">
                <label for="logo" class="font-small">Company logo</label>
                <input type="file" class="form-control font-small" id="logo" name="logo" value="{{old("logo")}}"/>
                {{--<span class="font-small error-message">Jhon</span>--}}
            </div>
            <div class="my-4">
                <label for="website" class="font-small">Company website</label>
                <input type="text" class="form-control font-small" id="website" name="website" value="{{old("website")}}"/>
                {{--<span class="font-small error-message">Jhon</span>--}}
            </div>
            <div class="my-4">
                <label for="phone" class="font-small">Company phone</label>
                <input type="text" class="form-control font-small" id="phone" name="phone" value="{{old("phone")}}"/>
                {{--<span class="font-small error-message">Jhon</span>--}}
            </div>
            <div class="my-4">
                <label for="email" class="font-small">Email</label>
                <input type="text" class="form-control font-small" id="email" name="email" value="{{old("email")}}"/>
                {{--<span class="font-small error-message">name@example.com</span>--}}
            </div>
            <div class="my-4">
                <label for="password" class="font-small">Password</label>
                <input type="password" class="form-control font-small" id="password" name="password" value="{{old("password")}}"/>
                {{--  <span class="font-small error-message">Your password needs to be at least 8 characters long and contain at least one letter and one number</span>--}}
            </div>
            <div class="my-4">
                <label for="confirmPassword" class="font-small">Confirm password</label>
                <input type="password" class="form-control font-small" id="confirmPassword" name="confirmPassword" value="{{old("confirmPassword")}}"/>
                {{--<span class="font-small error-message">Your password needs to be at least 8 characters long and contain at least one letter and one number</span>--}}
            </div>
            <button id="btnRegister" class="btn btn-primary text-center d-block mx-auto px-4">
                Register
            </button>
            <br/>
            <a href="/login" class="signInFormLink" class="font-small">Already have an account? Log in instead.</a>
        </form>
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
            </div>
        </div>
    </div>
@endsection
