@extends('layouts.layout')
@section('title')
    FindYourJob | Job
@endsection
@section('content')
    <div id="company-wrapper" class="w-75 py-5 mx-auto">
        <div id="logo" class="text-center">
            <img src="assets/img/testimonial-4.jpg" alt="Sarah Doerty">
        </div>
        <h3 class="text-center font-xl pt-3 pd-0">Sarah Doerty</h3>
        <div class="text-center mb-5">
            <span class="text-truncate me-3"><i class="fa fa-envelope text-primary me-2"></i>sarahdoerty@mail.com</span>
            <span class="text-truncate me-3"><i class="fa fa-phone text-primary me-2"></i>+381/60-123-2545</span>
            <br/>
            <!--razmisliti da li ostaviti dugme za gledanje profila (dovoljan je CV i coverletter)-->
            <a href="/account" target="_blank" class="btn btn-primary mt-3 mb-5">View profile</a>
            <p class="my-0">Uploaded file:</p><a href="assets/documents/uploaded_files_at_jobs/CV.pdf" target="_blank" class="btn btn-primary mt-1">View document</a>
        </div>
        <h3 class="font-xl py-3">Cover Letter</h3>
        <p class="font-small">
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore
            et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
            Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit
            amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna
            aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita
            kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.
        </p>
        <!-- Jobs End -->
    </div>
@endsection
