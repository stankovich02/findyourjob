<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/




Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/about', [App\Http\Controllers\AboutController::class, 'index'])->name('about');

Route::resource('jobs', \App\Http\Controllers\JobController::class);

Route::resource('companies', \App\Http\Controllers\CompanyController::class);

Route::get('/contact', [App\Http\Controllers\ContactController::class, 'index'])->name('contact');

Route::middleware('IsLoggedIn')->group(function (){
    Route::get('/account', [App\Http\Controllers\AccountController::class, 'index'])->name('account');
    Route::get('/application', [App\Http\Controllers\ApplicationController::class, 'index'])->name('application.index');
    Route::get('/logout', [App\Http\Controllers\LoginController::class, 'logout'])->name('logout');
});

Route::middleware('IsNotLoggedIn')->group(function (){
    Route::controller(\App\Http\Controllers\LoginController::class)->group(function (){
        Route::get('/login', 'index')->name('login');
        Route::post('/login', 'login')->name('loginUser');
    });
    Route::controller(\App\Http\Controllers\RegisterController::class)->group(function (){
        Route::get('/register', 'index')->name('register');
        Route::post('/register', 'register')->name('registerUser');
        Route::get('/verification/{token}', 'verify')->name('verify');
    });
});
